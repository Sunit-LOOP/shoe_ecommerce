<?php
require 'vendor/autoload.php';

\Stripe\Stripe::setApiKey('sk_test_51R9ot8IrQz5SX3CkFH19wRVzIlrC0gLzld1JvZf66QvgQJMmrNs9GfMqYzrOKww7gIkQBN3HStBefCeyuEpJI1Jx00fNq6myEe'); // R

$checkout_session = \Stripe\Checkout\Session::create([
    'line_items' => [[
        'price_data' => [
            'currency' => 'usd',
            'product_data' => [
                'name' => 'Shoe Order',
            ],
            'unit_amount' => 5000, // $50.00
        ],
        'quantity' => 1,
    ]],
    'mode' => 'payment',
    'success_url' => 'http://localhost/smss/success.php',
    'cancel_url' => 'http://localhost/smss/cancel.php',
]);

header("Location: " . $checkout_session->url);
exit;
