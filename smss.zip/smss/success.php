<?php
echo "<h1>✅ Payment Successful!</h1><p>Thank you for your order.</p>";
?>