    SIMPLE ONLINE SHOE STORE MANAGEMENT SYSTEM

2.	Extract the zipped source code. 
3.	Copy the folder you have extracted and paste it in (for xampp xamp/htdocs, for wampp wampp/www,for lamp var/www/html) root directory in your pc.
4.	Run your XAMPP Cpanel and start Apache and MYSQL.
5.	Open any of your browser (chrome, Firefox, etc) and go to the URL “http://localhost/phpmyadmin/”.
6.	Click on new.
7.	Create a new database with name shoe_store and click on create.
8.	Go to the top navigation bar and click on the import tab.
9.	The import page will open.
10.	Click on browse.
11.	Then browse for shoe_store.sql in the database folder we extracted and select it.
12.	Click on Go.
13.	After importing, open another tab on the browser and go to e.g. “http://localhost/online-shoe-store/”
14.	 For admin login, click Go to http://localhost/smss/Login.php?Role=Admin on your browser.



========= LOGIN DETAILS ===========
==ADMIN==

==USERNAME = admin
==PASSWORD = admin

==USER==

==USERNAME = mike
==PASSWORD = mike
    =====MORE: ALPHACODECAMP.COM.NG=====