<?php
session_start();
require 'Connection.php';

$ProductID = $_GET['ProductID'];
$CustomerID = $_GET['CustomerID'];
$ProductSize = $_POST['ProductSize'];
$ProductColor = $_POST['ProductColor'];
$DateOrder = date("Y/m/d");

// ✅ Check session
if (empty($_SESSION['Username']) || empty($_SESSION['Password'])) {
    echo "<script>
            window.alert('Please Login to Process your order');
            window.open('Login.php?Role=User','_self');
          </script>";
    exit();
}

// ✅ Insert order into tbl_orders
$sql2 = "INSERT INTO `tbl_orders`(`ProductID`, `CustomerID`, `Size`, `Color`, `DateOrdered`) 
         VALUES ('$ProductID','$CustomerID','$ProductSize','$ProductColor','$DateOrder')";

$res2 = mysqli_query($Conn, $sql2);

if ($res2) {
    // ✅ Redirect to payment page
    header("Location: Payment.php?ProductID=$ProductID&CustomerID=$CustomerID");
    exit();
} else {
    echo "Order Failed: " . mysqli_error($Conn);
}
?>
