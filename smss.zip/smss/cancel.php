<?php
echo "<h1>❌ Payment Cancelled!</h1><p>You cancelled the payment.</p>";
?>