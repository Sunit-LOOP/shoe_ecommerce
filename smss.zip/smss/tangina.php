<?php
	$Username = $_POST["Username"];
	$Password = $_POST["Password"];
	$_Role = $_GET["Role"];
	echo $Username;
	echo $Password;
	echo $_Role;
?>