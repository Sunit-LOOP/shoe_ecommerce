<?php
	$Host = "localhost";
	$Username = "root";
	$Password = "";
	$Db = "shoe_store";
	
	$Conn = mysqli_connect($Host,$Username,$Password,$Db);

?>